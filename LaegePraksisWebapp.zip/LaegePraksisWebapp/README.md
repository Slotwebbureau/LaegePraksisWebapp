# LægePraksis Webapp

Dette er en prototype af et lægepraksissystem inspireret af Sundhed.dk.

## Funktioner
- Login og rollebaseret adgang
- Patientjournaler
- Kalender og tidsbooking
- Receptfornyelse
- Internt beskedsystem
- Fakturering

## Teknologi
- Frontend: React + Tailwind CSS
- Backend: Node.js (Express)
- Database: PostgreSQL

## Installation
Kommer snart...

